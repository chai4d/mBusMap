delete from bus_path;
commit;

delete from bus_line;
commit;

delete from bus_info;
commit;

delete from point_name;
commit;

delete from point_info;
commit;
